# Now let me create sample data for the Climate Health Intelligence Platform
# to demonstrate what the project would contain

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json

# Set random seed for reproducibility
np.random.seed(42)

# Generate sample climate and health data for the demonstration
# This represents what the platform would work with using real APIs and datasets

# Generate date range for the last 2 years
end_date = datetime(2025, 9, 5)
start_date = end_date - timedelta(days=730)
date_range = pd.date_range(start=start_date, end=end_date, freq='D')

# Sample cities with coordinates
cities = [
    {'city': 'New York', 'lat': 40.7128, 'lon': -74.0060, 'population': 8500000},
    {'city': 'Los Angeles', 'lat': 34.0522, 'lon': -118.2437, 'population': 4000000},
    {'city': 'Chicago', 'lat': 41.8781, 'lon': -87.6298, 'population': 2700000},
    {'city': 'Houston', 'lat': 29.7604, 'lon': -95.3698, 'population': 2300000},
    {'city': 'Phoenix', 'lat': 33.4484, 'lon': -112.0740, 'population': 1700000},
    {'city': 'Miami', 'lat': 25.7617, 'lon': -80.1918, 'population': 470000},
    {'city': 'Seattle', 'lat': 47.6062, 'lon': -122.3321, 'population': 750000},
    {'city': 'Denver', 'lat': 39.7392, 'lon': -104.9903, 'population': 715000}
]

# Generate comprehensive climate and health dataset
data_records = []

for date in date_range:
    for city_info in cities:
        # Simulate seasonal temperature patterns
        day_of_year = date.timetuple().tm_yday
        base_temp = 15 + 10 * np.sin(2 * np.pi * (day_of_year - 80) / 365)
        
        # City-specific temperature adjustments
        city_temp_adjustments = {
            'Phoenix': 15, 'Miami': 10, 'Los Angeles': 5,
            'Houston': 5, 'New York': -2, 'Chicago': -5,
            'Seattle': -3, 'Denver': -3
        }
        
        base_temp += city_temp_adjustments.get(city_info['city'], 0)
        
        # Generate realistic climate data with some randomness
        temperature = base_temp + np.random.normal(0, 3)
        humidity = np.clip(50 + np.random.normal(0, 15), 20, 95)
        
        # Air quality - worse in larger cities and during certain seasons  
        base_aqi = 50 + (city_info['population'] / 1000000) * 20
        seasonal_factor = 1.2 if 150 < day_of_year < 250 else 0.8  # worse in summer
        aqi = np.clip(base_aqi * seasonal_factor + np.random.normal(0, 15), 10, 200)
        
        # PM2.5 correlated with AQI
        pm25 = (aqi - 50) * 0.5 + np.random.normal(0, 5)
        pm25 = np.clip(pm25, 0, 100)
        
        # Generate health impact data
        # Higher temperatures and worse air quality lead to more health issues
        temp_stress_factor = max(0, (temperature - 30) / 10)  # stress when temp > 30°C
        air_stress_factor = max(0, (aqi - 50) / 50)  # stress when AQI > 50
        
        # Respiratory issues influenced by air quality
        respiratory_cases = np.random.poisson(
            10 + air_stress_factor * 20 + np.random.normal(0, 2)
        )
        
        # Heat-related illnesses influenced by temperature
        heat_illness_cases = np.random.poisson(
            2 + temp_stress_factor * 15 + np.random.normal(0, 1)
        )
        
        # Cardiovascular issues influenced by both factors
        cardiovascular_cases = np.random.poisson(
            15 + (temp_stress_factor + air_stress_factor) * 10 + np.random.normal(0, 3)
        )
        
        # Hospital admissions as sum of health issues
        total_admissions = respiratory_cases + heat_illness_cases + cardiovascular_cases
        
        record = {
            'date': date.strftime('%Y-%m-%d'),
            'city': city_info['city'],
            'latitude': city_info['lat'],
            'longitude': city_info['lon'],
            'population': city_info['population'],
            'temperature_c': round(temperature, 1),
            'humidity_percent': round(humidity, 1),
            'aqi': round(aqi, 0),
            'pm25': round(pm25, 1),
            'respiratory_cases': max(0, respiratory_cases),
            'heat_illness_cases': max(0, heat_illness_cases),
            'cardiovascular_cases': max(0, cardiovascular_cases),
            'total_hospital_admissions': max(0, total_admissions)
        }
        
        data_records.append(record)

# Create DataFrame
df = pd.DataFrame(data_records)

# Save to CSV for the web application
df.to_csv('climate_health_data.csv', index=False)

# Create additional datasets for model training
print("Sample Climate Health Intelligence Data Generated:")
print(f"Total records: {len(df):,}")
print(f"Date range: {df['date'].min()} to {df['date'].max()}")
print(f"Cities: {', '.join(df['city'].unique())}")
print()

# Show sample data
print("Sample data (first 10 rows):")
print(df.head(10)[['date', 'city', 'temperature_c', 'aqi', 'total_hospital_admissions']])

print()
print("Data statistics:")
print(df[['temperature_c', 'aqi', 'pm25', 'total_hospital_admissions']].describe())

# Create model features summary
print()
print("=== ML MODEL FEATURES ===")
features = {
    "input_features": [
        "temperature_c", "humidity_percent", "aqi", "pm25", 
        "population", "day_of_year", "city_encoded"
    ],
    "target_variables": [
        "respiratory_cases", "heat_illness_cases", 
        "cardiovascular_cases", "total_hospital_admissions"
    ],
    "models_to_compare": [
        "Linear Regression", "Random Forest", "XGBoost", 
        "Support Vector Regression", "Neural Network"
    ]
}

for category, items in features.items():
    print(f"{category.replace('_', ' ').title()}:")
    for item in items:
        print(f"  • {item}")
    print()

# Create technology stack summary
tech_stack = {
    "data_sources": [
        "OpenWeatherMap API (real-time weather)",
        "EPA Air Quality API (pollution data)", 
        "Health department APIs (hospital data)",
        "Kaggle climate datasets (historical data)"
    ],
    "ml_libraries": [
        "Scikit-learn (traditional ML)",
        "XGBoost (gradient boosting)",
        "SHAP (model explainability)",
        "Pandas & NumPy (data processing)"
    ],
    "visualization": [
        "Plotly (interactive charts)",
        "Folium (maps)",
        "Streamlit (web interface)",
        "Seaborn (statistical plots)"
    ],
    "deployment": [
        "Streamlit Cloud (free hosting)",
        "GitHub (version control)",
        "Docker (containerization option)",
        "Heroku (alternative hosting)"
    ]
}

print("=== TECHNOLOGY STACK ===")
for category, items in tech_stack.items():
    print(f"{category.replace('_', ' ').title()}:")
    for item in items:
        print(f"  • {item}")
    print()

print("=== PROJECT ADVANTAGES ===")  
advantages = [
    "Uses trending 2025 data science topics (climate + health AI)",
    "Demonstrates multiple ML algorithms with comparison",
    "Includes explainable AI (SHAP) for model interpretability", 
    "Real-time data integration capabilities",
    "Interactive web dashboard for non-technical users",
    "Completely free tools and resources",
    "Addresses important societal issue (climate health)",
    "Scalable architecture for adding new features",
    "Production-ready deployment options",
    "Impressive for portfolio and job interviews"
]

for i, advantage in enumerate(advantages, 1):
    print(f"{i:2d}. {advantage}")