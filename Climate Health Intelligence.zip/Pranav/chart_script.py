import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Load the data
df = pd.read_csv('climate_health_data.csv')

# Create scatter plot showing correlation between AQI and respiratory cases
fig = px.scatter(
    df, 
    x='aqi', 
    y='respiratory_cases',
    color='city',
    title='AQI vs Respiratory Cases',
    labels={'aqi': 'AQI Level', 'respiratory_cases': 'Resp Cases'},
    hover_data=['temperature_c', 'total_hospital_admissions']
)

# Update layout with axis titles
fig.update_layout(
    xaxis_title='AQI Level',
    yaxis_title='Resp Cases'
)

# Save the chart
fig.write_image('aqi_respiratory_scatter.png')

print("Chart saved successfully!")
print(f"Number of unique cities: {df['city'].nunique()}")
print(f"AQI range: {df['aqi'].min():.1f} - {df['aqi'].max():.1f}")
print(f"Respiratory cases range: {df['respiratory_cases'].min()} - {df['respiratory_cases'].max()}")