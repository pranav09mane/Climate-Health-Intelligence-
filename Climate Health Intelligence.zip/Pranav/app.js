// Climate Health Intelligence Platform - JavaScript Application
class ClimateHealthApp {
    constructor() {
        this.data = [];
        this.filteredData = [];
        this.charts = {};
        this.currentSection = 'dashboard';
        
        this.init();
    }

    async init() {
        this.showLoading();
        await this.loadData();
        this.setupNavigation();
        this.setupEventListeners();
        this.initializeDashboard();
        this.hideLoading();
        
        // Ensure dashboard is shown by default
        this.showSection('dashboard');
    }

    showLoading() {
        const loadingEl = document.getElementById('loading-indicator');
        if (loadingEl) {
            loadingEl.classList.remove('hidden');
        }
    }

    hideLoading() {
        const loadingEl = document.getElementById('loading-indicator');
        if (loadingEl) {
            loadingEl.classList.add('hidden');
        }
    }

    async loadData() {
        try {
            const response = await fetch('https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/e1abd5ec7c8f0cc2e47be285d77d9114/4806de05-d0df-4f0e-b8d4-15e4c0afaa11/69c34fb2.csv');
            if (!response.ok) {
                throw new Error('Failed to load CSV data');
            }
            const csvText = await response.text();
            this.data = this.parseCSV(csvText);
            this.filteredData = [...this.data];
            console.log('Data loaded successfully:', this.data.length, 'records');
        } catch (error) {
            console.error('Error loading data:', error);
            // Fallback to sample data if CSV fails to load
            this.generateSampleData();
        }
    }

    parseCSV(csvText) {
        const lines = csvText.trim().split('\n');
        const headers = lines[0].split(',').map(h => h.trim());
        const data = [];

        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',');
            if (values.length === headers.length) {
                const row = {};
                headers.forEach((header, index) => {
                    const value = values[index].trim();
                    // Convert numeric values
                    if (!isNaN(value) && value !== '') {
                        row[header] = parseFloat(value);
                    } else {
                        row[header] = value;
                    }
                });
                data.push(row);
            }
        }
        return data;
    }

    generateSampleData() {
        const cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Miami', 'Seattle', 'Denver'];
        const startDate = new Date('2023-09-01');
        const endDate = new Date('2025-09-01');
        
        this.data = [];
        
        for (let city of cities) {
            for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 7)) {
                const temp = 15 + Math.random() * 25 + (city === 'Phoenix' ? 10 : 0) + (city === 'Miami' ? 8 : 0);
                const humidity = 30 + Math.random() * 40 + (city === 'Miami' ? 20 : 0);
                const aqi = 20 + Math.random() * 80 + (city === 'Los Angeles' ? 30 : 0);
                const pm25 = 5 + Math.random() * 20 + (aqi - 50) * 0.3;
                
                const respiratory_cases = Math.round(10 + aqi * 0.8 + Math.random() * 10);
                const heat_illness_cases = Math.round(5 + Math.max(0, temp - 25) * 2 + Math.random() * 5);
                const cardiovascular_cases = Math.round(8 + temp * 0.5 + aqi * 0.3 + Math.random() * 8);
                const total_hospital_admissions = respiratory_cases + heat_illness_cases + cardiovascular_cases + Math.round(Math.random() * 10);
                
                this.data.push({
                    date: d.toISOString().split('T')[0],
                    city: city,
                    latitude: 40 + Math.random() * 10,
                    longitude: -120 + Math.random() * 40,
                    population: 500000 + Math.random() * 8000000,
                    temperature_c: Math.round(temp * 10) / 10,
                    humidity_percent: Math.round(humidity),
                    aqi: Math.round(aqi),
                    pm25: Math.round(pm25 * 10) / 10,
                    respiratory_cases: respiratory_cases,
                    heat_illness_cases: heat_illness_cases,
                    cardiovascular_cases: cardiovascular_cases,
                    total_hospital_admissions: total_hospital_admissions
                });
            }
        }
        
        this.filteredData = [...this.data];
        console.log('Generated sample data:', this.data.length, 'records');
    }

    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                if (section) {
                    this.showSection(section);
                }
            });
        });
    }

    showSection(sectionName) {
        console.log('Switching to section:', sectionName);
        
        // Hide all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        
        // Remove active class from nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        
        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
        }
        
        // Add active class to corresponding nav link
        const activeNavLink = document.querySelector(`[data-section="${sectionName}"]`);
        if (activeNavLink) {
            activeNavLink.classList.add('active');
        }
        
        this.currentSection = sectionName;
        
        // Initialize section-specific functionality
        setTimeout(() => {
            switch (sectionName) {
                case 'dashboard':
                    this.initializeDashboard();
                    break;
                case 'data-explorer':
                    this.initializeDataExplorer();
                    break;
                case 'visualizations':
                    this.initializeVisualizations();
                    break;
                case 'ml-models':
                    this.initializeMLModels();
                    break;
                case 'predictor':
                    this.initializePredictor();
                    break;
                case 'analytics':
                    this.initializeAnalytics();
                    break;
            }
        }, 100);
    }

    setupEventListeners() {
        // Data Explorer events
        const applyFiltersBtn = document.getElementById('apply-filters');
        if (applyFiltersBtn) {
            applyFiltersBtn.addEventListener('click', () => this.applyFilters());
        }
        
        const exportDataBtn = document.getElementById('export-data');
        if (exportDataBtn) {
            exportDataBtn.addEventListener('click', () => this.exportData());
        }
        
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.searchData(e.target.value));
        }
        
        // Predictor form
        const predictionForm = document.getElementById('prediction-form');
        if (predictionForm) {
            predictionForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.makePrediction();
            });
        }
    }

    initializeDashboard() {
        this.updateMetrics();
        this.createOverviewChart();
        this.createHealthSummaryChart();
    }

    updateMetrics() {
        if (this.data.length === 0) return;
        
        const avgTemp = this.data.reduce((sum, d) => sum + d.temperature_c, 0) / this.data.length;
        const avgAQI = this.data.reduce((sum, d) => sum + d.aqi, 0) / this.data.length;
        const totalAdmissions = this.data.reduce((sum, d) => sum + d.total_hospital_admissions, 0);
        
        const avgTempEl = document.getElementById('avg-temp');
        const avgAqiEl = document.getElementById('avg-aqi');
        const totalAdmissionsEl = document.getElementById('total-admissions');
        
        if (avgTempEl) avgTempEl.textContent = `${avgTemp.toFixed(1)}°C`;
        if (avgAqiEl) avgAqiEl.textContent = avgAQI.toFixed(0);
        if (totalAdmissionsEl) totalAdmissionsEl.textContent = totalAdmissions.toLocaleString();
    }

    createOverviewChart() {
        const ctx = document.getElementById('overview-chart');
        if (!ctx) return;
        
        if (this.charts.overview) {
            this.charts.overview.destroy();
        }

        const monthlyData = this.aggregateByMonth();
        
        this.charts.overview = new Chart(ctx, {
            type: 'line',
            data: {
                labels: monthlyData.labels,
                datasets: [{
                    label: 'Average Temperature (°C)',
                    data: monthlyData.temperature,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y'
                }, {
                    label: 'Average AQI',
                    data: monthlyData.aqi,
                    borderColor: '#FFC185',
                    backgroundColor: 'rgba(255, 193, 133, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Temperature (°C)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'AQI'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });
    }

    createHealthSummaryChart() {
        const ctx = document.getElementById('health-summary-chart');
        if (!ctx) return;
        
        if (this.charts.healthSummary) {
            this.charts.healthSummary.destroy();
        }

        const cityData = this.aggregateByCity();
        
        this.charts.healthSummary = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: cityData.cities,
                datasets: [{
                    label: 'Respiratory Cases',
                    data: cityData.respiratory,
                    backgroundColor: '#B4413C'
                }, {
                    label: 'Heat Illness',
                    data: cityData.heatIllness,
                    backgroundColor: '#FFC185'
                }, {
                    label: 'Cardiovascular',
                    data: cityData.cardiovascular,
                    backgroundColor: '#5D878F'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Cities'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Average Cases per Day'
                        }
                    }
                }
            }
        });
    }

    aggregateByMonth() {
        const monthlyData = {};
        
        this.data.forEach(row => {
            const date = new Date(row.date);
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            
            if (!monthlyData[monthKey]) {
                monthlyData[monthKey] = {
                    temperature: [],
                    aqi: [],
                    count: 0
                };
            }
            
            monthlyData[monthKey].temperature.push(row.temperature_c);
            monthlyData[monthKey].aqi.push(row.aqi);
            monthlyData[monthKey].count++;
        });
        
        const labels = Object.keys(monthlyData).sort();
        const temperature = labels.map(month => {
            const temps = monthlyData[month].temperature;
            return temps.reduce((sum, t) => sum + t, 0) / temps.length;
        });
        const aqi = labels.map(month => {
            const aqis = monthlyData[month].aqi;
            return aqis.reduce((sum, a) => sum + a, 0) / aqis.length;
        });
        
        return { labels, temperature, aqi };
    }

    aggregateByCity() {
        const cityData = {};
        
        this.data.forEach(row => {
            if (!cityData[row.city]) {
                cityData[row.city] = {
                    respiratory: 0,
                    heatIllness: 0,
                    cardiovascular: 0,
                    count: 0
                };
            }
            
            cityData[row.city].respiratory += row.respiratory_cases;
            cityData[row.city].heatIllness += row.heat_illness_cases;
            cityData[row.city].cardiovascular += row.cardiovascular_cases;
            cityData[row.city].count++;
        });
        
        const cities = Object.keys(cityData);
        const respiratory = cities.map(city => Math.round(cityData[city].respiratory / cityData[city].count));
        const heatIllness = cities.map(city => Math.round(cityData[city].heatIllness / cityData[city].count));
        const cardiovascular = cities.map(city => Math.round(cityData[city].cardiovascular / cityData[city].count));
        
        return { cities, respiratory, heatIllness, cardiovascular };
    }

    initializeDataExplorer() {
        this.populateCityFilter();
        this.populateDataTable();
        this.updateRecordCount();
    }

    populateCityFilter() {
        const cityFilter = document.getElementById('city-filter');
        if (!cityFilter) return;
        
        const cities = [...new Set(this.data.map(d => d.city))].sort();
        
        cityFilter.innerHTML = '<option value="">All Cities</option>';
        cities.forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            cityFilter.appendChild(option);
        });
    }

    populateDataTable() {
        const tbody = document.querySelector('#data-table tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        this.filteredData.slice(0, 100).forEach(row => { // Limit to 100 rows for performance
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${row.date}</td>
                <td>${row.city}</td>
                <td>${row.temperature_c}</td>
                <td>${row.humidity_percent}%</td>
                <td>${row.aqi}</td>
                <td>${row.pm25}</td>
                <td>${row.respiratory_cases}</td>
                <td>${row.total_hospital_admissions}</td>
            `;
            tbody.appendChild(tr);
        });
    }

    updateRecordCount() {
        const recordCountEl = document.getElementById('record-count');
        if (recordCountEl) {
            recordCountEl.textContent = `Records: ${this.filteredData.length}`;
        }
    }

    applyFilters() {
        const cityFilter = document.getElementById('city-filter');
        const startDate = document.getElementById('date-start');
        const endDate = document.getElementById('date-end');
        
        const cityValue = cityFilter ? cityFilter.value : '';
        const startValue = startDate ? startDate.value : '';
        const endValue = endDate ? endDate.value : '';
        
        this.filteredData = this.data.filter(row => {
            let include = true;
            
            if (cityValue && row.city !== cityValue) include = false;
            if (startValue && row.date < startValue) include = false;
            if (endValue && row.date > endValue) include = false;
            
            return include;
        });
        
        this.populateDataTable();
        this.updateRecordCount();
    }

    searchData(searchTerm) {
        if (!searchTerm) {
            this.applyFilters();
            return;
        }
        
        const filtered = this.filteredData.filter(row =>
            Object.values(row).some(value =>
                String(value).toLowerCase().includes(searchTerm.toLowerCase())
            )
        );
        
        const tbody = document.querySelector('#data-table tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        filtered.slice(0, 100).forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${row.date}</td>
                <td>${row.city}</td>
                <td>${row.temperature_c}</td>
                <td>${row.humidity_percent}%</td>
                <td>${row.aqi}</td>
                <td>${row.pm25}</td>
                <td>${row.respiratory_cases}</td>
                <td>${row.total_hospital_admissions}</td>
            `;
            tbody.appendChild(tr);
        });
        
        const recordCountEl = document.getElementById('record-count');
        if (recordCountEl) {
            recordCountEl.textContent = `Records: ${filtered.length}`;
        }
    }

    exportData() {
        const csv = this.convertToCSV(this.filteredData);
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'climate_health_data_filtered.csv';
        a.click();
        window.URL.revokeObjectURL(url);
    }

    convertToCSV(data) {
        if (data.length === 0) return '';
        
        const headers = Object.keys(data[0]);
        const csvRows = [headers.join(',')];
        
        data.forEach(row => {
            const values = headers.map(header => String(row[header]));
            csvRows.push(values.join(','));
        });
        
        return csvRows.join('\n');
    }

    initializeVisualizations() {
        this.createTrendsChart();
        this.createCorrelationChart();
        this.createCityComparisonChart();
    }

    createTrendsChart() {
        const ctx = document.getElementById('trends-chart');
        if (!ctx) return;
        
        if (this.charts.trends) {
            this.charts.trends.destroy();
        }
        
        const monthlyData = this.aggregateByMonth();
        
        this.charts.trends = new Chart(ctx, {
            type: 'line',
            data: {
                labels: monthlyData.labels,
                datasets: [{
                    label: 'Temperature (°C)',
                    data: monthlyData.temperature,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4
                }, {
                    label: 'AQI',
                    data: monthlyData.aqi,
                    borderColor: '#FFC185',
                    backgroundColor: 'rgba(255, 193, 133, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });
    }

    createCorrelationChart() {
        const ctx = document.getElementById('correlation-chart');
        if (!ctx) return;
        
        if (this.charts.correlation) {
            this.charts.correlation.destroy();
        }
        
        const cities = [...new Set(this.data.map(d => d.city))];
        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325'];
        
        const datasets = cities.map((city, index) => {
            const cityData = this.data.filter(d => d.city === city);
            return {
                label: city,
                data: cityData.map(d => ({
                    x: d.aqi,
                    y: d.respiratory_cases
                })),
                backgroundColor: colors[index % colors.length],
                borderColor: colors[index % colors.length]
            };
        });
        
        this.charts.correlation = new Chart(ctx, {
            type: 'scatter',
            data: { datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Air Quality Index (AQI)'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Respiratory Cases'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });
    }

    createCityComparisonChart() {
        const ctx = document.getElementById('city-comparison-chart');
        if (!ctx) return;
        
        if (this.charts.cityComparison) {
            this.charts.cityComparison.destroy();
        }
        
        const cityData = this.aggregateByCity();
        
        this.charts.cityComparison = new Chart(ctx, {
            type: 'bar', 
            data: {
                labels: cityData.cities,
                datasets: [{
                    label: 'Average Hospital Admissions',
                    data: cityData.cities.map(city => {
                        const cityRows = this.data.filter(d => d.city === city);
                        return cityRows.reduce((sum, d) => sum + d.total_hospital_admissions, 0) / cityRows.length;
                    }),
                    backgroundColor: '#1FB8CD'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Cities'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Average Hospital Admissions'
                        }
                    }
                }
            }
        });
    }

    initializeMLModels() {
        this.createFeatureImportanceChart();
    }

    createFeatureImportanceChart() {
        const ctx = document.getElementById('feature-importance-chart');
        if (!ctx) return;
        
        if (this.charts.featureImportance) {
            this.charts.featureImportance.destroy();
        }
        
        const features = ['AQI', 'Temperature', 'PM2.5', 'Humidity', 'Population', 'Latitude'];
        const importance = [0.45, 0.25, 0.15, 0.08, 0.04, 0.03];
        
        this.charts.featureImportance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: features,
                datasets: [{
                    label: 'Feature Importance',
                    data: importance,
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Importance Score'
                        },
                        beginAtZero: true,
                        max: 0.5
                    }
                }
            }
        });
    }

    initializePredictor() {
        // Predictor is ready, form submission handled by event listener
        console.log('Predictor initialized');
    }

    makePrediction() {
        const city = document.getElementById('pred-city')?.value;
        const temp = parseFloat(document.getElementById('pred-temp')?.value);
        const humidity = parseFloat(document.getElementById('pred-humidity')?.value);
        const aqi = parseFloat(document.getElementById('pred-aqi')?.value);
        const pm25 = parseFloat(document.getElementById('pred-pm25')?.value);
        
        if (!city || isNaN(temp) || isNaN(humidity) || isNaN(aqi) || isNaN(pm25)) {
            alert('Please fill in all fields with valid values');
            return;
        }
        
        // Simple prediction model based on correlations
        const respiratoryCases = Math.round(10 + aqi * 0.8 + Math.random() * 5);
        const heatIllnessCases = Math.round(5 + Math.max(0, temp - 25) * 2 + Math.random() * 3);
        const cardiovascularCases = Math.round(8 + temp * 0.5 + aqi * 0.3 + Math.random() * 4);
        const totalAdmissions = respiratoryCases + heatIllnessCases + cardiovascularCases;
        
        let riskLevel = 'Low';
        let riskClass = 'risk-low';
        let recommendations = [
            'Continue regular outdoor activities',
            'Monitor air quality occasionally',
            'Stay hydrated in hot weather'
        ];
        
        if (totalAdmissions > 40) {
            riskLevel = 'High';
            riskClass = 'risk-high';
            recommendations = [
                'Limit outdoor activities during peak hours',
                'Use air purifiers indoors',
                'Seek medical attention if experiencing symptoms',
                'Stay in air-conditioned environments'
            ];
        } else if (totalAdmissions > 25) {
            riskLevel = 'Medium';
            riskClass = 'risk-medium';
            recommendations = [
                'Reduce prolonged outdoor exposure',
                'Wear masks when air quality is poor',
                'Stay hydrated and cool',
                'Monitor symptoms closely'
            ];
        }
        
        const confidence = (85 + Math.random() * 10).toFixed(1);
        const lowerBound = Math.round(totalAdmissions * 0.8);
        const upperBound = Math.round(totalAdmissions * 1.2);
        
        const resultHTML = `
            <div class="risk-result">
                <div class="risk-level ${riskClass}">${riskLevel} Risk</div>
                <div class="prediction-value">${totalAdmissions} predicted admissions</div>
                <div class="confidence-interval">95% CI: ${lowerBound} - ${upperBound} (Confidence: ${confidence}%)</div>
                <div class="recommendations">
                    <h4>Recommendations:</h4>
                    <ul>
                        ${recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
        
        const outputEl = document.getElementById('prediction-output');
        if (outputEl) {
            outputEl.innerHTML = resultHTML;
        }
    }

    initializeAnalytics() {
        this.createSeasonalChart();
        this.createPerformanceChart();
        this.updateAnalyticsStats();
    }

    createSeasonalChart() {
        const ctx = document.getElementById('seasonal-chart');
        if (!ctx) return;
        
        if (this.charts.seasonal) {
            this.charts.seasonal.destroy();
        }
        
        const seasonalData = this.aggregateBySeason();
        
        this.charts.seasonal = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Spring', 'Summer', 'Fall', 'Winter'],
                datasets: [{
                    label: 'Respiratory Cases',
                    data: seasonalData.respiratory,
                    borderColor: '#B4413C',
                    backgroundColor: 'rgba(180, 65, 60, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Heat Illness Cases',
                    data: seasonalData.heatIllness,
                    borderColor: '#FFC185',
                    backgroundColor: 'rgba(255, 193, 133, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });
    }

    createPerformanceChart() {
        const ctx = document.getElementById('performance-chart');
        if (!ctx) return;
        
        if (this.charts.performance) {
            this.charts.performance.destroy();
        }
        
        const cityPerformance = this.calculateCityPerformance();
        
        this.charts.performance = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Air Quality', 'Temperature Control', 'Health Outcomes', 'Population Density', 'Overall Score'],
                datasets: cityPerformance.datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    aggregateBySeason() {
        const seasons = { Spring: [], Summer: [], Fall: [], Winter: [] };
        
        this.data.forEach(row => {
            const month = new Date(row.date).getMonth() + 1;
            let season;
            if (month >= 3 && month <= 5) season = 'Spring';
            else if (month >= 6 && month <= 8) season = 'Summer';
            else if (month >= 9 && month <= 11) season = 'Fall';
            else season = 'Winter';
            
            seasons[season].push(row);
        });
        
        const respiratory = Object.keys(seasons).map(season => {
            const data = seasons[season];
            return data.length > 0 ? data.reduce((sum, d) => sum + d.respiratory_cases, 0) / data.length : 0;
        });
        
        const heatIllness = Object.keys(seasons).map(season => {
            const data = seasons[season];
            return data.length > 0 ? data.reduce((sum, d) => sum + d.heat_illness_cases, 0) / data.length : 0;
        });
        
        return { respiratory, heatIllness };
    }

    calculateCityPerformance() {
        const cities = ['New York', 'Los Angeles', 'Chicago'];
        const colors = ['#1FB8CD', '#FFC185', '#B4413C'];
        
        const datasets = cities.map((city, index) => {
            const cityData = this.data.filter(d => d.city === city);
            if (cityData.length === 0) return null;
            
            const avgAQI = cityData.reduce((sum, d) => sum + d.aqi, 0) / cityData.length;
            const avgTemp = cityData.reduce((sum, d) => sum + d.temperature_c, 0) / cityData.length;
            const avgAdmissions = cityData.reduce((sum, d) => sum + d.total_hospital_admissions, 0) / cityData.length;
            
            // Normalize scores (higher is better)
            const airQuality = Math.max(0, 100 - avgAQI);
            const tempControl = Math.max(0, 100 - Math.abs(avgTemp - 22) * 3);
            const healthOutcomes = Math.max(0, 100 - avgAdmissions * 2);
            const populationDensity = 75; // Mock score
            const overallScore = (airQuality + tempControl + healthOutcomes + populationDensity) / 4;
            
            return {
                label: city,
                data: [airQuality, tempControl, healthOutcomes, populationDensity, overallScore],
                borderColor: colors[index],
                backgroundColor: colors[index] + '33',
                pointBackgroundColor: colors[index]
            };
        }).filter(dataset => dataset !== null);
        
        return { datasets };
    }

    updateAnalyticsStats() {
        // Calculate highest risk city
        const cityRisks = {};
        this.data.forEach(row => {
            if (!cityRisks[row.city]) cityRisks[row.city] = [];
            cityRisks[row.city].push(row.total_hospital_admissions);
        });
        
        let highestRisk = '';
        let maxAvgRisk = 0;
        Object.keys(cityRisks).forEach(city => {
            const avgRisk = cityRisks[city].reduce((sum, r) => sum + r, 0) / cityRisks[city].length;
            if (avgRisk > maxAvgRisk) {
                maxAvgRisk = avgRisk;
                highestRisk = city;
            }
        });
        
        const highestRiskEl = document.getElementById('highest-risk-city');
        const strongestCorrelationEl = document.getElementById('strongest-correlation');
        
        if (highestRiskEl) highestRiskEl.textContent = highestRisk;
        if (strongestCorrelationEl) strongestCorrelationEl.textContent = 'AQI ↔ Respiratory (0.95)';
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing Climate Health App...');
    new ClimateHealthApp();
});