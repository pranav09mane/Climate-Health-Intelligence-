# Climate Health Intelligence Platform 🌡️🏥

An AI-powered platform that analyzes climate data to predict health impacts and provides actionable insights using machine learning and explainable AI.

## 🚀 Features

- **Real-time Climate Analysis**: Process weather and air quality data
- **Health Risk Prediction**: ML models to predict hospital admissions
- **Interactive Dashboard**: User-friendly web interface built with Streamlit
- **Explainable AI**: SHAP integration for model interpretability
- **Multiple ML Models**: Compare Linear Regression, Random Forest, XGBoost, and more
- **Data Visualization**: Interactive charts and maps

## 🛠️ Technologies Used

- **Python**: Core programming language
- **Streamlit**: Web application framework
- **Scikit-learn & XGBoost**: Machine learning algorithms
- **SHAP**: Model explainability
- **Plotly**: Interactive visualizations
- **Pandas & NumPy**: Data processing

## 📊 Data Sources

- Weather APIs (OpenWeatherMap, Open-Meteo)
- Air Quality APIs (EPA, OpenAQ)
- Health datasets (simulated for demo)
- Climate datasets from Kaggle

## 🔧 Installation

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run the app: `streamlit run app.py`

## 🎯 2025 Data Science Trends Addressed

- ✅ AI-driven healthcare analytics
- ✅ Climate change data science  
- ✅ Explainable AI (XAI)
- ✅ Real-time data processing
- ✅ Interactive dashboards
- ✅ Automated machine learning

## 📱 Live Demo

[View the deployed application here](https://your-app-url.streamlit.app)

## 🤝 Contributing

Contributions welcome! Please read our contribution guidelines.

## 📄 License

MIT License - see LICENSE file for details.
